This version of base64.exe is compiled for a 64-bit X64 Windows platform.
